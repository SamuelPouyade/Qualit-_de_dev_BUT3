<?php

namespace GildedRose\Strategy;

use GildedRose\Item;
class CommonItemStrategy implements IProvideUpdateStrategy{
    public function updateQuality(Item $item): void
    {
        if ($item->quality > 0) {
            $item->quality = $item->quality - 1;
            if ($item->sellIn < 0 && $item->quality > 0) {
                $item->quality = $item->quality - 1;
            }
        }
    }

    public function updateSellIn(Item $item): void
    {
        $item->sellIn = $item->sellIn - 1;
    }
}