<?php

namespace GildedRose\Strategy;

use GildedRose\Item;

interface IProvideUpdateStrategy
{
    public function updateQuality(Item $item): void;
    public function updateSellIn(Item $item): void;

}