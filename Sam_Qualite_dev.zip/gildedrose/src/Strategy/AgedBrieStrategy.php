<?php

namespace GildedRose\Strategy;
use GildedRose\Item;
class AgedBrieStrategy implements IProvideUpdateStrategy
{

    public function updateQuality(Item $item):void{
        $increase = $item->sellIn <= 0
            ? 2
            : 1;
        $item->quality = min(50, $item->quality + $increase);
    }
    public function updateSellIn(Item $item):void
    {
        $item->sellIn -= 1;
    }
}