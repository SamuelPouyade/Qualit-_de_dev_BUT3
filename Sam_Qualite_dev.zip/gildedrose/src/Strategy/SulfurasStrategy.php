<?php

namespace GildedRose\Strategy;
use GildedRose\Item;
class SulfurasStrategy implements IProvideUpdateStrategy
{

    public function updateQuality(Item $item):void{
        //Ne rien faire
    }
    public function updateSellIn(Item $item):void
    {
        //Ne rien faire
    }
}