<?php

declare(strict_types=1);

namespace GildedRose;

use GildedRose\Strategy\AgedBrieStrategy;
use GildedRose\Strategy\BackstageStrategy;
use GildedRose\Strategy\CommonItemStrategy;
use GildedRose\Strategy\SulfurasStrategy;

final class GildedRose
{
    /**
     * @var Item[]
     */
    public function __construct(array $items)
    {
        $this->items = $items;
        $this->commonItemStrategy = new CommonItemStrategy();
        $this->agedBrieStrategy = new AgedBrieStrategy();
        $this->sulfurasStrategy = new SulfurasStrategy();
        $this->backstageStrategy = new BackstageStrategy();
    }

    public function updateQuality(): void
    {
        foreach ($this->items as $item) {
            switch ($item->name) {
                case 'Aged Brie' :
                    $strategy = new AgedBrieStrategy($item);
                    $strategy->updateQuality($item);
                    $strategy->updateSellIn($item);
                    break;
                case 'Sulfuras, Hand of Ragnaros':
                    $strategy = new SulfurasStrategy($item);
                    $strategy->updateQuality($item);
                    $strategy->updateSellIn($item);
                    break;
                case 'Backstage passes to a TAFKAL80ETC concert':
                    $strategy = new BackstageStrategy($item);
                    $strategy->updateQuality($item);
                    $strategy->updateSellIn($item);
                    break;
                default:
                    $strategy = new CommonItemStrategy();
                    $strategy->updateQuality($item);
                    $strategy->updateSellIn($item);
            }
        }
    }






}