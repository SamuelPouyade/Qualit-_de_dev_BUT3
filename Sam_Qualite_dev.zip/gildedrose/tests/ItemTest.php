<?php

namespace Tests;

use PHPUnit\Framework\Attributes\Test;
use GildedRose\Item;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;


class ItemTest extends TestCase
{
    #[Test]
    public function should_return_item_object_in_string(): void
    {
        $item = new Item('Aged Brie', 10, 10);
        $expectedString = 'Aged Brie, 10, 10';

        self::assertEquals($expectedString, $item);
    }
}