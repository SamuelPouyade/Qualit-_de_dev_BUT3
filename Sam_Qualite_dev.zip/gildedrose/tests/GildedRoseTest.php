<?php

declare(strict_types=1);

namespace Tests;


use GildedRose\GildedRose;
use GildedRose\Item;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\TestCase;

class GildedRoseTest extends TestCase
{
    #[Test]
    public function quality_decrease_by_1_when_common_item_is_not_expired(): void
    {
        $item = new Item('Common item', 5, 10);
        $gildedRose = new GildedRose([$item]);

        $gildedRose->updateQuality();

        self::assertThat($item->quality, self::identicalTo(9));
    }

    #[Test]
    public function quality_decrease_by_2_when_common_item_is_expired(): void
    {
        $item = new Item('Common item', 0, 10);
        $gildedRose = new GildedRose([$item]);

        $gildedRose->updateQuality();

        self::assertThat($item->quality, self::identicalTo(8));

    }

    #[Test]
    public function quality_for_common_item_can_not_be_negative(): void
    {
        $item = new Item('Common item', 1, 0);
        $gildedRose = new GildedRose([$item]);

        $gildedRose->updateQuality();

        self::assertThat($item->quality, self::identicalTo(0));

    }

    #[Test]
    public function quality_for_common_item_can_not_be_negative_for_expired_product(): void
    {
        $item = new Item('Common item', 0, 1);
        $gildedRose = new GildedRose([$item]);

        $gildedRose->updateQuality();

        self::assertThat($item->quality, self::identicalTo(0));

    }

    #[Test]
    public function sellin_for_common_item_decrease_by_1(): void
    {
        $item = new Item('Common item', 5, 0);
        $gildedRose = new GildedRose([$item]);

        $gildedRose->updateQuality();

        self::assertThat($item->sellIn, self::identicalTo(4));

    }

    #[Test]
    public function sellin_for_common_item_can_be_negative(): void
    {
        $item = new Item('Common item', 0, 0);
        $gildedRose = new GildedRose([$item]);

        $gildedRose->updateQuality();

        self::assertThat($item->quality, self::identicalTo(0));

    }
    #[Test]
    #[DataProvider('AgedBriQualityDataProvider')]
    public function should_verify_quality_for_aged_bri(int $sellIn, int $quality, int
                                                           $expectedQuality, string $rule): void
    {
        $item = new Item('Aged Brie', $sellIn, $quality);
        $gildedRose = new GildedRose([$item]);
        $gildedRose->updateQuality();
        self::assertThat($item->quality, self::identicalTo($expectedQuality), $rule);
    }

    #[Test]
    #[DataProvider('GenericSellInDataProvider')]
    public function should_verify_sellin_for_aged_bri(int $sellIn, int
                                                          $expectedSellIn, string $rule): void
    {
        $item = new Item('Aged Brie', $sellIn, 10);
        $gildedRose = new GildedRose([$item]);
        $gildedRose->updateQuality();
        self::assertThat($item->sellIn, self::identicalTo($expectedSellIn), $rule);
    }

    public static function AgedBriQualityDataProvider(): array
    {
        return [
            [5, 10, 11, 'quality increase of 1'],
            [0, 10, 12, 'quality increase of 2 for expired product'],
            [1, 50, 50, 'quality can not be upper than 50'],
            [5, -3, -2, 'quality increase by 1 for aged bri created with negative quality']
        ];
    }

    public static function GenericSellInDataProvider(): array
    {
        return [
            [20, 19, 'sellIn decrease by 1'],
            [0, -1, 'sellIn can become negative'],
            [-2, -3, 'sellIn decrease if negative'],
        ];
    }

    #[Test]
    #[DataProvider('SulfurasSellInDataProvider')]
    public function sulfuras_sellin_and_quality_must_never_change(int $sellIn, int $quality, string $rule): void
    {
        $item = new Item('Sulfuras, Hand of Ragnaros', $sellIn, $quality);
        $gildedRose = new GildedRose([$item]);
        $gildedRose->updateQuality();
        self::assertThat($item->sellIn, self::identicalTo($sellIn), $rule);
        self::assertThat($item->quality, self::identicalTo($quality), $rule);
    }

    #[Test]
    #[DataProvider('SulfurasSellInDataProviderNeverChange')]
    public function sulfuras_sellin_and_quality_must_never_change_for_expired_product(int $sellIn, int $quality, string $rule): void
    {
        $item = new Item('Sulfuras, Hand of Ragnaros', $sellIn, $quality);
        $gildedRose = new GildedRose([$item]);
        $gildedRose->updateQuality();
        self::assertThat($item->sellIn, self::identicalTo($sellIn), $rule);
        self::assertThat($item->quality, self::identicalTo($quality), $rule);
    }
    public static function SulfurasSellInDataProvider(): array
    {
        return [
            [5, 10, 'sellIn must never change'],
        ];
    }
    public static function SulfurasSellInDataProviderNeverChange(): array
    {
        return [
            [-2, 4, 'sellIn must never change for expired product'],
        ];
    }

    #[Test]
    #[DataProvider('BackstageQualityDataProvider')]
    public function BackstageQuality(int $sellIn, int $quality, int $expectedQuality, string $rule): void
    {
        $item = new Item('Backstage passes to a TAFKAL80ETC concert', $sellIn, $quality);
        $gildedRose = new GildedRose([$item]);
        $gildedRose->updateQuality();
        self::assertEquals($expectedQuality, $item->quality, $rule);
    }



    public static function BackstageQualityDataProvider(): array
    {
        return [
            [20, 50, 50, 'quality_of_backstage_can_not_go_upper_50'],
            [11, 20, 21,
                'quality_of_backstage_increase_by_1_for_sellin_greater_or_equal_to_11_day'],
            [10, 20, 22,
                'quality_of_backstage_increase_by_2_for_sellin_less_or_equal_to_10_day'],
            [5, 20, 23,
                'quality_of_backstage_increase_by_2_for_sellin_less_or_equal_to_5_day'],
            [0, 20, 0, 'quality fall to 0 for expired backstage'],
        ];
    }
}
